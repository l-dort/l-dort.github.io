#_OooO_PCA ORANGE JUICE_OooO_#
#_o_IFISA 2A AA_o_#

rm(list=ls()) # to remove all Global Environment
dev.off()     # to remove all Plots


#_oo_0. LOADING NEEDED PACKAGES_oo_#
#_Installation
if(!require(ggplot2)) install.packages("ggplot2")
if(!require(FactoMineR)) install.packages("FactoMineR")
if(!require(factoextra)) install.packages("factoextra")

#_Loading
library(ggplot2)
library(FactoMineR)
library(factoextra)
#_O:_:O_#



#_oo_1. LOADING OF DATA_oo_#
orange <- read.table(file.choose(), 
                     header = TRUE, 
                     sep = '\t',
                     row.names = 1, 
                     check.names = FALSE
                     )
#_O:_:O_#



#_oo_2. FIRST DESCRIPTION OF DATA_oo_#
str(orange)
#_O:_:O_#



#_oo_3. PCA IN ACTION_oo_#
#_PCA
acp_orange <- PCA(orange,             # which data ?
                  scale.unit = TRUE,  # center and reduction of data
                  ncp = Inf,          # how many component want you keep ? Inf =  all
                  quanti.sup = 9:16,  # specify columns which are quantitative supplementary variables
                  quali.sup = c("Origine", "Conditionnement"), # specify columns which are qualitative supplementary variables
                  graph = F           # draw graph ? F = FALSE
                  )

#_Plots of PCA
#_o_Individuals
plot.PCA(acp_orange, 
         axes = c(1,2), # select your dimensions of projection
         choix = "ind", # select the graph : ind for individuals or var for variables
         title = "PCA graph of individuals",     # title of the graph
         autolab = "auto"# labels are placed in a "good" way
         )

#_o_Variables
# with all variables
plot.PCA(acp_orange, 
         axes = c(1,2),   # select your dimensions of projection
         choix = "var",   # graph of variables
         title = "PCA graph of variables",     # title of the graph
         autolab = "yes", # labels are placed in a "good" way
         cex = 1       # size of the labels
         )

# with only actives variables
plot.PCA(acp_orange, 
         axes = c(1,2),
         choix = "var",
         invisible = "quanti.sup", # indicate the variables that you do not want draw
         title = "PCA graph of active variables",
         autolab = "yes",
         cex = 1
         )

# with only supplementary variables
plot.PCA(acp_orange, 
         axes = c(1,2),
         choix = "var",
         invisible = "var",
         title = "PCA graph of supplementary variables",
         autolab = "yes",
         cex = 1
         )

#_plot of variables with only Fructose
plot.PCA(acp_orange,
         axes = c(1,2),
         choix = "var",
         select = c("Fructose"),
         invisible = "quanti.sup",
         title = "PCA graph of variables",
         autolab = "yes",
         cex = 1
)

#_plot of variables with only Titre and Glucose
plot.PCA(acp_orange, 
         axes = c(1,2),
         choix = "var",
         select = c("Titre", "Glucose"),
         title = "PCA graph of variables Titre and Glucose",
         autolab = "yes",
         cex = 1
         )

#_Indicators of PCA
acp_orange$eig
acp_orange$ind
acp_orange$ind.sup
acp_orange$var
acp_orange$quali.sup
acp_orange$quanti.sup
#_O:_:O_#



#_oo_4. INTRODUCTION TO CAH_oo_#
#_CAH via FactoMineR
cah_orange <- HCPC(acp_orange, graph = TRUE)
#_O:_:O_#
