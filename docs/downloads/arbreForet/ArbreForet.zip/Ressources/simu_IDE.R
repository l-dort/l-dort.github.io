# Simulation des données — Cas 1 : filière avicole

set.seed(2026)
n <- 400

data_avicole <- data.frame(
  type_batiment    = sample(c("statique", "dynamique"), 
                            n, 
                            replace = TRUE, 
                            prob = c(0.4, 0.6)),
  densite          = round(runif(n, 14, 22), 1),
  age_jours        = sample(10:42, 
                            n, 
                            replace = TRUE),
  effectif         = round(rnorm(n, mean = 20000, sd = 4000)),
  brumisation      = sample(c("oui", "non"), 
                            n, 
                            replace = TRUE, 
                            prob = c(0.35, 0.65)),
  THI_interieur    = round(rnorm(n, mean = 79, sd = 6), 1),
  duree_exposition = pmax(0, round(rnorm(n, mean = 8, sd = 6)))
)
 
data_avicole$THI_interieur    <- pmin(pmax(data_avicole$THI_interieur, 62), 92)
data_avicole$duree_exposition <- pmin(data_avicole$duree_exposition, 53)
data_avicole$effectif         <- pmax(5000, data_avicole$effectif)

# Score latent : effet seuil du THI interne, aggrave par forte densite et batiment statique
# attenue par brumisation ; sensibilite plus forte pour les lots ages (emplumes, moins tolerants)
score <- with(data_avicole,
  -15 +
  0.19 * THI_interieur +
  0.25 * (densite - 18) +
  ifelse(type_batiment == "statique", 2.0, 0) +
  ifelse(brumisation == "oui", -2.8, 0) +
  0.05 * duree_exposition +
  0.04 * (age_jours - 25)
)
 
proba_surmortalite <- 1 / (1 + exp(-score))

data_avicole$surmortalite <- factor(
  ifelse(rbinom(n, 1, proba_surmortalite) == 1, "risque_eleve", "risque_faible"),
  levels = c("risque_faible", "risque_eleve")
)
 
data_avicole <- data_avicole %>%
  mutate(type_batiment = factor(type_batiment), brumisation = factor(brumisation))
 
str(data_avicole)
prop.table(table(data_avicole$surmortalite))
 
write.csv(data_avicole, file = "data_avicole.csv", row.names = FALSE)


# Simulation des données — Cas 2 : filière bovine laitière

set.seed(2026)
n <- 400

data_laitiere <- data.frame(
  race             = sample(c("Holstein", "Montbeliarde", "Normande"),
                              n, replace = TRUE, prob = c(0.5, 0.3, 0.2)),
  parite           = sample(1:6, n, replace = TRUE),
  THI              = round(rnorm(n, mean = 74, sd = 7), 1),
  ombrage          = sample(c("oui", "non"), n, replace = TRUE, prob = c(0.45, 0.55)),
  acces_eau        = sample(c("facile", "limite"), n, replace = TRUE, prob = c(0.6, 0.4)),
  duree_exposition = pmax(0, round(rnorm(n, mean = 8, sd = 6)))
)

data_laitiere$THI              <- pmin(pmax(data_laitiere$THI, 55), 88)
data_laitiere$duree_exposition <- pmin(data_laitiere$duree_exposition, 53)

# Effet seuil : pas de perte sous ~68, plateau croissant, saturation physiologique au-dela de 82
effet_THI <- pmax(0, data_laitiere$THI - 68) * 0.35
effet_THI <- pmin(effet_THI, 6)

perte_base <- effet_THI +
  ifelse(data_laitiere$ombrage == "oui", -1.2, 0) +
  ifelse(data_laitiere$acces_eau == "limite", 0.8, 0) +
  0.04 * data_laitiere$duree_exposition +
  ifelse(data_laitiere$race == "Holstein", 0.6, 0)

data_laitiere$perte_production <- round(pmax(0, perte_base + rnorm(n, 0, 0.8)), 2)

data_laitiere <- data_laitiere %>%
  mutate(race = factor(race), ombrage = factor(ombrage), acces_eau = factor(acces_eau))

str(data_laitiere)
summary(data_laitiere$perte_production)

write.csv(data_laitiere, file = "data_laitiere.csv", row.names = FALSE)
